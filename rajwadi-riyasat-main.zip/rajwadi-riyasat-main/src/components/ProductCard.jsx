import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useCart } from '../context/CartContext';
import { ShoppingBag } from 'lucide-react';

export default function ProductCard({ product }) {
  const [activeImage, setActiveImage] = useState(product.thumbnails[0]);
  const [selectedSize, setSelectedSize] = useState(product.sizes[0]);
  const { addToCart } = useCart();

  const handleAddToCart = () => {
    addToCart({
      id: product.id + '-' + Date.now(),
      name: product.name,
      price: product.price,
      size: selectedSize,
      img: activeImage
    });
  };

  const handleInstagramOrder = (e) => {
    e.preventDefault();
    const text = `Hello! I want to order:\n\n${product.name}\nSize: ${selectedSize}\nPrice: ₹${product.price}\n\nLink: ${window.location.origin}`;

    if (navigator.clipboard) {
      navigator.clipboard.writeText(text).then(() => {
        alert('Product details copied to clipboard! Please paste them in our Instagram DM.');
        window.open('https://ig.me/m/rajwadi_riyasat_', '_blank');
      }).catch(() => {
        window.open('https://www.instagram.com/rajwadi_riyasat_?igsh=Z3dqbTJhdjJkc3Fs', '_blank');
      });
    } else {
      window.open('https://www.instagram.com/rajwadi_riyasat_?igsh=Z3dqbTJhdjJkc3Fs', '_blank');
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 40 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-50px" }}
      transition={{ duration: 0.6 }}
      className="bg-white rounded-2xl overflow-hidden shadow-lg shadow-gray-200/50 hover:shadow-xl hover:-translate-y-1 transition-all duration-300 relative flex flex-col group border border-gray-100"
    >
      <span className={`absolute top-4 left-4 text-white px-4 py-1.5 text-[10px] uppercase tracking-widest font-bold rounded-sm z-10 ${product.badgeColor}`}>
        {product.badge}
      </span>

      <div className="w-full h-[520px] bg-gray-50 relative overflow-hidden">
        <AnimatePresence mode="wait">
          <motion.img
            key={activeImage}
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 1.02 }}
            transition={{ duration: 0.4 }}
            src={activeImage}
            alt={product.title}
            className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
          />
        </AnimatePresence>
      </div>

      <div className="flex justify-center gap-3 p-4 bg-white z-10 relative -mt-6">
        {product.thumbnails.map((thumb, idx) => (
          <img
            key={idx}
            src={thumb}
            onClick={() => setActiveImage(thumb)}
            className={`w-[60px] h-[80px] object-cover rounded-lg cursor-pointer border-2 transition-all duration-300 shadow-sm ${activeImage === thumb ? 'border-gold-accent scale-110 shadow-md z-10' : 'border-white hover:border-gray-200'}`}
            alt="thumbnail"
          />
        ))}
      </div>

      <div className="p-6 flex flex-col flex-grow z-10 bg-white">
        <div className="text-[0.75rem] font-bold uppercase text-gold-accent tracking-widest mb-2">{product.brand}</div>
        <div className="font-playfair text-xl md:text-2xl font-bold text-dark-premium leading-tight">{product.title}</div>

        <div className="flex items-center gap-3 my-4">
          <span className="text-2xl font-bold text-dark-premium">₹{product.price}</span>
          <span className="line-through text-text-muted text-sm">₹{product.oldPrice}</span>
          <span className="text-[#ff905a] text-sm font-bold bg-[#fff0e6] px-2 py-1 rounded">{product.discount}</span>
        </div>

        <div className="text-xs font-semibold mt-2 text-text-muted uppercase tracking-wider mb-2">Select Size</div>
        <select
          value={selectedSize}
          onChange={(e) => setSelectedSize(e.target.value)}
          className="w-full p-3 mb-6 border border-gray-200 rounded-lg bg-gray-50 text-sm outline-none focus:border-gold-accent focus:ring-1 focus:ring-gold-accent transition-all"
        >
          {product.sizes.map((size, idx) => (
            <option key={idx} value={size}>{size}</option>
          ))}
        </select>

        <div className="flex flex-col sm:flex-row gap-3 mt-auto">
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={handleAddToCart}
            className="flex-1 flex items-center justify-center gap-2 bg-dark-premium text-white py-3.5 font-semibold text-sm rounded-lg hover:bg-black transition-colors"
          >
            <ShoppingBag size={18} />
            Add to Cart
          </motion.button>
          <motion.a
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={handleInstagramOrder}
            href="#"
            className="flex-1 flex items-center justify-center gap-2 bg-gradient-to-r from-pink-500 to-orange-400 text-white py-3.5 text-sm font-semibold rounded-lg hover:opacity-90 transition-opacity shadow-md"
          >
            Instagram DM
          </motion.a>
        </div>
      </div>
    </motion.div>
  );
}
