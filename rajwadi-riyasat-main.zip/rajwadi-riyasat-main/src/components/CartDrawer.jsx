import { motion, AnimatePresence } from 'framer-motion';
import { useCart } from '../context/CartContext';
import { X, Trash2, ShoppingBag } from 'lucide-react';

export default function CartDrawer() {
  const { cart, isCartOpen, toggleCart, removeFromCart } = useCart();

  const total = cart.reduce((sum, item) => sum + item.price, 0);

  const handleWhatsAppCheckout = (e) => {
    e.preventDefault();
    if (cart.length === 0) return;
    
    let text = "Hello! I want to order:\n\n";
    cart.forEach((item, index) => {
        text += `${index + 1}. ${item.name} - Size: ${item.size} - ₹${item.price}\n`;
    });
    text += `\nTotal: ₹${total}`;
    
    const encodedText = encodeURIComponent(text);
    window.open(`https://wa.me/919979155695?text=${encodedText}`, '_blank');
  };

  return (
    <AnimatePresence>
      {isCartOpen && (
        <>
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => toggleCart(false)}
            className="fixed inset-0 bg-black/40 backdrop-blur-sm z-[1500]"
          />
          <motion.div 
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'tween', duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
            className="fixed top-0 right-0 w-full max-w-[420px] h-full bg-white/90 backdrop-blur-xl shadow-2xl z-[2000] flex flex-col p-6 border-l border-white/40"
          >
            <div className="flex justify-between items-center border-b border-gray-200/50 pb-5 mb-5">
              <h3 className="text-xl font-playfair font-bold text-dark-premium flex items-center gap-2">
                <ShoppingBag className="text-gold-accent" /> My Cart
              </h3>
              <button onClick={() => toggleCart(false)} className="text-gray-400 hover:text-dark-premium transition-colors bg-gray-100/50 p-2 rounded-full hover:bg-gray-200">
                <X size={20} />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto custom-scrollbar">
              {cart.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-text-muted opacity-60">
                  <ShoppingBag size={64} className="mb-4 text-gray-300" />
                  <p className="text-lg font-medium">Your cart is empty</p>
                </div>
              ) : (
                <div className="flex flex-col gap-5 pr-2">
                  <AnimatePresence>
                    {cart.map((item, idx) => (
                      <motion.div 
                        key={item.id} 
                        layout
                        initial={{ opacity: 0, scale: 0.95, y: 20 }}
                        animate={{ opacity: 1, scale: 1, y: 0 }}
                        exit={{ opacity: 0, scale: 0.9, x: 20 }}
                        transition={{ duration: 0.2 }}
                        className="flex gap-4 p-3 bg-white rounded-xl shadow-sm border border-gray-100 items-center group"
                      >
                        <img src={item.img} alt={item.name} className="w-[65px] h-[85px] object-cover rounded-md" />
                        <div className="flex-1">
                          <div className="text-sm font-bold text-dark-premium line-clamp-2 leading-snug">{item.name}</div>
                          <div className="text-xs text-text-muted mt-1.5 font-medium bg-gray-50 inline-block px-2 py-0.5 rounded">Size: {item.size}</div>
                          <div className="text-sm font-bold text-gold-accent mt-2">₹{item.price}</div>
                        </div>
                        <button onClick={() => removeFromCart(idx)} className="text-red-400 p-2 hover:text-red-600 hover:bg-red-50 rounded-full transition-colors opacity-70 group-hover:opacity-100">
                          <Trash2 size={18} />
                        </button>
                      </motion.div>
                    ))}
                  </AnimatePresence>
                </div>
              )}
            </div>

            <div className="border-t border-gray-200/50 pt-5 mt-5">
              <div className="flex justify-between items-end mb-6">
                <span className="text-text-muted font-medium">Grand Total</span>
                <span className="text-2xl font-bold text-dark-premium">₹{total}</span>
              </div>
              <motion.button 
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={handleWhatsAppCheckout}
                className="w-full flex justify-center items-center gap-2 bg-[#25D366] text-white py-4 font-bold rounded-xl shadow-lg shadow-green-500/20 hover:bg-[#20bd5a] transition-colors text-sm uppercase tracking-wider"
              >
                Checkout on WhatsApp
              </motion.button>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
