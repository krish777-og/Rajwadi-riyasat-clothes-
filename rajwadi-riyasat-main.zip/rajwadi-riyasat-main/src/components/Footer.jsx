export default function Footer() {
  return (
    <footer className="bg-dark-premium text-white pt-20 pb-10 border-t-4 border-gold-accent mt-20">
      <div className="max-w-6xl mx-auto px-6 grid grid-cols-1 md:grid-cols-3 gap-12 mb-12">
        <div>
          <h4 className="font-playfair text-2xl font-bold text-gold-accent mb-6">Rajwadi Riyasat</h4>
          <p className="text-gray-400 font-light leading-relaxed mb-6">
            Purveyors of the finest traditional Indian wear. We bring elegance, quality, and regal aesthetics to your wardrobe.
          </p>
        </div>
        <div>
          <h4 className="font-playfair text-lg font-bold mb-6">Quick Links</h4>
          <ul className="space-y-3 text-gray-400 font-light">
            <li><a href="#" className="hover:text-gold-accent transition-colors">Home</a></li>
            <li><a href="#shop" className="hover:text-gold-accent transition-colors">New Arrivals</a></li>
            <li><a href="#shop" className="hover:text-gold-accent transition-colors">Lehenga Choli</a></li>
            <li><a href="#" className="hover:text-gold-accent transition-colors">Contact Us</a></li>
          </ul>
        </div>
        <div>
          <h4 className="font-playfair text-lg font-bold mb-6">Newsletter</h4>
          <p className="text-gray-400 font-light mb-4">Subscribe to receive updates, access to exclusive deals, and more.</p>
          <div className="flex gap-2">
            <input type="email" placeholder="Enter your email address" className="bg-white/10 px-4 py-2 flex-1 rounded text-sm text-white placeholder-gray-500 outline-none focus:bg-white/20 transition-colors" />
            <button className="bg-gold-accent text-white px-4 py-2 rounded font-medium hover:bg-[#9a7625] transition-colors">Subscribe</button>
          </div>
        </div>
      </div>
      <div className="border-t border-white/10 pt-8 text-center">
        <p className="text-gray-500 font-light text-sm">&copy; 2026 Rajwadi Riyasat Marketplace. All Rights Reserved.</p>
      </div>
    </footer>
  );
}
