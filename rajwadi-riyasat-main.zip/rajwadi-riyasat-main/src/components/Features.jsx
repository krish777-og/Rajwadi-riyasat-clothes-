import { motion } from 'framer-motion';
import { Sparkles, Scissors, Truck } from 'lucide-react';

const features = [
  {
    icon: <Sparkles size={32} className="text-gold-accent mb-4" />,
    title: "Premium Quality",
    description: "Handcrafted with the finest fabrics and intricate Zari work, ensuring unparalleled elegance."
  },
  {
    icon: <Truck size={32} className="text-gold-accent mb-4" />,
    title: "All India Delivery",
    description: "Fast, secure, and reliable shipping straight to your doorstep across all over India."
  }
];

export default function Features() {
  return (
    <div className="py-20 bg-white">
      <div className="max-w-6xl mx-auto px-5">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
          {features.map((feature, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ delay: idx * 0.2, duration: 0.6 }}
              className="flex flex-col items-center text-center p-6 rounded-2xl hover:bg-gray-50 transition-colors"
            >
              {feature.icon}
              <h3 className="font-playfair text-xl font-bold mb-3 text-dark-premium">{feature.title}</h3>
              <p className="text-text-muted font-light leading-relaxed">
                {feature.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}
