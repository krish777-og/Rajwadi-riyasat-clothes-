import { useState, useEffect } from 'react';
import { ShoppingCart, Search, Menu } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { motion } from 'framer-motion';

export default function Navbar() {
  const { cart, toggleCart } = useCart();
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <motion.nav 
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ type: "spring", stiffness: 100, damping: 20 }}
      className={`fixed top-0 w-full z-[1000] transition-all duration-300 px-6 py-4 flex items-center justify-between ${
        scrolled ? 'bg-white/80 backdrop-blur-md shadow-sm border-b border-gray-100' : 'bg-transparent'
      }`}
    >
      <div className="flex items-center gap-4">
        <button className={`lg:hidden ${scrolled ? 'text-dark-premium' : 'text-white'}`}>
          <Menu size={24} />
        </button>
        <a href="#" className={`font-playfair text-xl md:text-2xl font-bold tracking-widest ${
          scrolled ? 'text-gold-accent' : 'text-white drop-shadow-md'
        }`}>
          Rajwadi Riyasat
        </a>
      </div>
      
      <div className="hidden lg:flex flex-1 max-w-xl mx-8">
        <div className="relative w-full">
          <input 
            type="text" 
            placeholder="Search collections..."
            className={`w-full px-5 py-2.5 rounded-full text-sm outline-none transition-all ${
              scrolled ? 'bg-gray-100 text-gray-800' : 'bg-white/20 backdrop-blur-sm text-white placeholder-gray-200 border border-white/30 focus:bg-white/30'
            }`}
          />
          <button className={`absolute right-1 top-1 bottom-1 px-4 rounded-full flex items-center justify-center transition-colors ${
            scrolled ? 'bg-gold-accent text-white hover:bg-[#9a7625]' : 'bg-white text-dark-premium hover:bg-gray-100'
          }`}>
            <Search size={16} />
          </button>
        </div>
      </div>
      
      <div className="flex items-center gap-6">
        <a href="#shop" className={`hidden md:block font-medium text-sm tracking-wide transition-colors ${
          scrolled ? 'text-dark-premium hover:text-gold-accent' : 'text-white hover:text-gold-accent drop-shadow-md'
        }`}>
          COLLECTIONS
        </a>
        <motion.div 
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          className={`relative cursor-pointer flex items-center gap-2 ${
            scrolled ? 'text-dark-premium' : 'text-white drop-shadow-md'
          }`}
          onClick={() => toggleCart(true)}
        >
          <ShoppingCart size={24} />
          {cart.length > 0 && (
            <motion.span 
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              className="bg-myntra-pink text-white text-[10px] md:text-xs px-1.5 py-0.5 rounded-full absolute -top-2 -right-2 font-bold shadow-sm"
            >
              {cart.length}
            </motion.span>
          )}
        </motion.div>
      </div>
    </motion.nav>
  );
}
