import { motion } from 'framer-motion';

export default function Hero() {
  const scrollToShop = (e) => {
    e.preventDefault();
    document.getElementById('shop').scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="relative min-h-screen flex items-center justify-center overflow-hidden bg-dark-premium">
      {/* Background Image with Parallax-like scale */}
      <motion.div
        initial={{ scale: 1.1 }}
        animate={{ scale: 1 }}
        transition={{ duration: 2, ease: "easeOut" }}
        className="absolute inset-0 z-0"
      >
        <img
          src="https://i.ibb.co/tTyR5sLL/new1-jpeg.jpg"
          alt="Premium Chaniya Choli Collection"
          className="w-full h-full object-cover object-top md:object-center"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/80 via-black/50 to-black/20"></div>
      </motion.div>

      {/* Content */}
      <div className="relative z-10 text-center px-5 max-w-4xl mx-auto mt-20">
        <motion.span
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5, duration: 0.8 }}
          className="block text-gold-accent font-medium tracking-[0.2em] mb-4 text-sm md:text-base uppercase"
        >
          Exclusive 2026 Collection
        </motion.span>

        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7, duration: 0.8 }}
          className="font-playfair text-5xl md:text-7xl lg:text-8xl text-white font-bold leading-tight drop-shadow-lg mb-6"
        >
          Elegance in <br className="hidden md:block"/> Every Thread
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.9, duration: 0.8 }}
          className="text-gray-200 text-lg md:text-xl font-light mb-10 max-w-2xl mx-auto drop-shadow-md"
        >
          Discover our premium selection of intricately embroidered traditional Indian Chaniya Cholis, designed for royalty.
        </motion.p>

        <motion.a
          href="#shop"
          onClick={scrollToShop}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.1, duration: 0.8 }}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          className="inline-block bg-gold-accent text-white px-10 py-4 rounded-full font-medium tracking-wide shadow-lg hover:bg-[#9a7625] transition-colors"
        >
          EXPLORE COLLECTION
        </motion.a>
      </div>
    </div>
  );
}
