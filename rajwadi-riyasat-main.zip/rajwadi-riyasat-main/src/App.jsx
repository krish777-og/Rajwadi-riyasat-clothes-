import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Features from './components/Features';
import Footer from './components/Footer';
import ProductCard from './components/ProductCard';
import CartDrawer from './components/CartDrawer';
import { products } from './data/products';
import { motion } from 'framer-motion';

function App() {
  return (
    <div className="min-h-screen flex flex-col bg-bg-light">
      <Navbar />
      <Hero />
      <Features />
      
      <main id="shop" className="flex-1 max-w-6xl w-full mx-auto py-20 px-5 scroll-mt-20">
        <div className="text-center mb-16">
          <motion.span 
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="text-gold-accent font-bold tracking-[0.2em] uppercase text-sm"
          >
            Curated For You
          </motion.span>
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="font-playfair text-4xl md:text-5xl font-bold text-dark-premium mt-4"
          >
            Featured Collections
          </motion.h2>
          <div className="w-24 h-1 bg-gold-accent mx-auto mt-6"></div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-10">
          {products.map(product => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </main>

      <Footer />
      <CartDrawer />
    </div>
  );
}

export default App;
