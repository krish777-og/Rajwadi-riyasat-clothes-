import { render, screen, fireEvent } from '@testing-library/react';
import { expect, it, describe } from 'vitest';
import ProductCard from '../components/ProductCard';
import { CartProvider } from '../context/CartContext';
import { products } from '../data/products';

describe('ProductCard Component', () => {
  it('renders product details correctly', () => {
    const product = products[0];
    render(
      <CartProvider>
        <ProductCard product={product} />
      </CartProvider>
    );
    
    expect(screen.getByText(product.title)).toBeInTheDocument();
    expect(screen.getByText(`₹${product.price}`)).toBeInTheDocument();
    expect(screen.getByText(product.badge)).toBeInTheDocument();
  });
});
