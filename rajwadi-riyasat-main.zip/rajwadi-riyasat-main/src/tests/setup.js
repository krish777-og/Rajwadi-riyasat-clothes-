import '@testing-library/jest-dom';

// Mock IntersectionObserver for Framer Motion testing
class IntersectionObserverMock {
  constructor() {}
  observe() {}
  unobserve() {}
  disconnect() {}
}
global.IntersectionObserver = IntersectionObserverMock;
