export const products = [
  {
    id: 1,
    name: 'Lehenga Choli (Royal Red)',
    title: 'Designer Wedding Lehenga Choli - Royal Red',
    brand: 'Rajwadi Exclusive',
    price: 1999,
    oldPrice: 3999,
    discount: '(50% OFF)',
    badge: 'BEST SELLER',
    badgeColor: 'bg-myntra-pink',
    mainImage: 'https://i.ibb.co/tTyR5sLL/new1-jpeg.jpg',
    thumbnails: [
      'https://i.ibb.co/tTyR5sLL/new1-jpeg.jpg',
      'https://i.ibb.co/DXyGQy5/IMG-20260528-WA0009.jpg',
      'https://i.ibb.co/ZzXKnBbt/IMG-20260528-WA0010.jpg'
    ],
    sizes: ['M upto L margin (Fully Stitched)', 'XL upto 2xl margin (Fully Stitched)'],
    instaLink: 'https://www.instagram.com/rajwadi_riyasat_/'
  },
  {
    id: 2,
    name: 'Lehenga Choli (Deep Navy Blue)',
    title: 'Designer Wedding Lehenga Choli - Deep Navy Blue',
    brand: 'Rajwadi Exclusive',
    price: 1999,
    oldPrice: 3999,
    discount: '(50% OFF)',
    badge: 'PREMIUM',
    badgeColor: 'bg-gold-accent',
    mainImage: 'https://i.ibb.co/BJ7H42F/IMG-20260529-170213.png',
    thumbnails: [
      'https://i.ibb.co/BJ7H42F/IMG-20260529-170213.png',
      'https://i.ibb.co/cXY5bYXs/IMG-20260528-WA0007.jpg',
      'https://i.ibb.co/M5D8pGs3/IMG-20260528-WA0008.jpg'
    ],
    sizes: ['M upto L margin (Fully Stitched)', 'XL upto 2xl margin (Fully Stitched)'],
    instaLink: 'https://www.instagram.com/rajwadi_riyasat_/'
  }
];
